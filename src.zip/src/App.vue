<template>
  <div id=content>
    <Team :players="players" :currentPlayer="currentPlayer" :currentShop="currentShop"
          @perso="currentPlayer = players[$event]"/>

    <World :towns="towns" :currentTown="currentTown" :currentStreet="currentStreet" :currentShop="currentShop"
           @town="currentTown = towns[$event]; currentStreet = undefined; currentShop = undefined"
           @street="currentStreet = currentTown.streets[$event]; currentShop = undefined"
           @shop="currentShop = currentStreet.shops[$event]"/>
  </div>
</template>

<script>
import Team from "./components/Team/Team";
import World from "./components/World/World";
import {team, villes} from "./model";

export default {
  name: 'App',
  components: {
    Team,
    World
  },
  data: () => {
    return {
      players: team,
      towns: villes,
      currentPlayer: team[0],
      currentTown: undefined,
      currentStreet: undefined,
      currentShop: undefined,
    };
  }
};
</script>

<style>
#content {
  display: flex;
  flex-flow: row nowrap;
  justify-content: space-evenly;
}
</style>
