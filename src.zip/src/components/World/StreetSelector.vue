<template>
  <select v-model.number="selected" @change="$emit('change', selected)">
    <option v-for="(street, index) in streets" :key="index" :value="index">
      {{ street }}
    </option>
  </select>
</template>

<script>
export default {
  name: "StreetSelector",
  props: {
    streets: Array
  },
  data() {
    return {
      selected: undefined
    };
  },
  emits: ['change'],
};
</script>

<style scoped>

</style>
