<template>
  <p>Choisissez la destination de votre personnage</p>
  <select v-model.number="selected" @change="$emit('change', selected)">
    <option v-for="(town, index) in towns" :key="index" :value="index">
      {{ town }}
    </option>
  </select>
</template>

<script>
export default {
  name: "TownSelector",
  props: {
    towns: Array
  },
  data() {
    return {
      selected: undefined
    };
  },
  emits: ['change'],
};
</script>

<style scoped>

</style>
