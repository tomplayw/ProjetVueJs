<template>
  <slot name="name" :shopName="shop.name">
    <h3>Vous entrez dans {{ shop.name }}</h3>
  </slot>

  <div id="items">
    <div>
      <slot name="stockHeader">
        <h4>En stock</h4>
      </slot>
      <pre>{{ shop.itemStock }}</pre>
    </div>
    <div>
      <slot name="orderHeader">
        <h4>A la demande</h4>
      </slot>
      <pre>{{ shop.itemOrder }}</pre>
    </div>
  </div>
</template>

<script>
export default {
  name: "Shop",
  props: {
    shop: Object
  },
};
</script>

<style scoped>
#items {
  display: flex;
  justify-content: space-around;
}
</style>
