<template>
  <div>
    <h2 v-if="currentTown">Vous vous trouvez à : {{ currentTown.name }}</h2>
    <TownSelector :towns="towns.map((t) => `${t.name} (${t.streets.length} rues)`)" @change="$emit('town', $event)"/>
    <StreetSelector v-if="currentTown" :streets="currentTown.streets.map((s) => `${s.name} (${s.shops.length} magasins)`)" @change="$emit('street', $event)"/>
    <ShopSelector v-if="currentStreet" :shops="currentStreet.shops.map((s) => `${s.name} (${s.itemCat.join(', ')})`)" @change="$emit('shop', $event)"/>
    <Shop v-if="currentShop" :shop="currentShop"/>
  </div>
</template>

<script>
import TownSelector from "./TownSelector";
import StreetSelector from "./StreetSelector";
import ShopSelector from "./ShopSelector";
import Shop from "./Shop";

export default {
  name: "World",
  props: {
    towns: Array,
    currentTown: Object,
    currentStreet: Object,
    currentShop: Object,
  },
  components: {
    TownSelector,
    StreetSelector,
    ShopSelector,
    Shop
  },
  emits: ['town', 'street', 'shop']
};
</script>

<style scoped>

</style>
