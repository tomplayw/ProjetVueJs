<template>
  <select v-model.number="selected" @change="$emit('change', selected)">
    <option v-for="(shop, index) in shops" :key="index" :value="index">
      {{ shop }}
    </option>
  </select>
</template>

<script>
export default {
  name: "ShopSelector",
  props: {
    shops: Array
  },
  data() {
    return {
      selected: undefined
    };
  },
  emits: ['change'],
};
</script>

<style scoped>

</style>
