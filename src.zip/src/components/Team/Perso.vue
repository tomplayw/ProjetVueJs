<template>
  <PersoCaracs :player="currentPlayer"/>
  <PersoSlots :player="currentPlayer" :shop="currentShop"/>
  <PersoOps :player="currentPlayer" :shop="currentShop"/>
</template>

<script>
import PersoCaracs from "./PersoCaracs";
import PersoSlots from "./PersoSlots";
import PersoOps from "./PersoOps";

export default {
  name: "Perso",
  props: {
    currentPlayer: Object,
    currentShop: Object
  },
  components: {
    PersoCaracs,
    PersoSlots,
    PersoOps
  },
  emits: ["change"],
};
</script>

<style scoped>

</style>
