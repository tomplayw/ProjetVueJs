<template>
  <div id="options">
    <div v-if="shop && shop.itemStock.length > 0">
      <select v-model.number="idxItemBuy">
        <option v-for="(item, index) in shop.itemStock" :key="index" :value="index">{{ item.name }}</option>
      </select>
      <button @click="player.buy(shop.itemStock[idxItemBuy])">Acheter</button>
    </div>

    <div v-if="shop && shop.itemOrder.length > 0">
      <select v-model.number="idxItemOrder">
        <option v-for="(item, index) in shop.itemOrder" :key="index" :value="index">{{ item.name }}</option>
      </select>
      <button @click="shop.order(idxItemOrder);">Commander</button>
    </div>
  </div>
</template>

<script>
export default {
  name: "PersoOps",
  props: {
    player: Object,
    shop: Object
  },
  data() {
    return {
      idxItemBuy: 0,
      idxItemOrder: 0,
      itemRemove: undefined,
    };
  }
};
</script>

<style scoped>
</style>
