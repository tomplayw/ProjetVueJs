<template>
  <div>
    <table>
      <thead>
      <tr>
        <th>Slot</th>
        <th>Items</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="(slot, index) in player.slots" :key="index">
        <td>{{ slot.name }}</td>
        <td>{{ slot.items.map(i => i.name).join(', ') || "vide" }}</td>
      </tr>
      </tbody>
    </table>

    <p>Items achetés : {{ player.boughtItems.map((item) => item.name).join(", ") || "rien" }}</p>

    <select v-model.number="itemAssign">
      <option v-for="(item, index) in player.boughtItems" :key="index" :value="index">{{ item.name }}</option>
    </select>
    <select v-model.number="itemAssignSlot">
      <option v-for="(slot, index) in player.slots" :key="index" :value="slot.id">{{ slot.name }}</option>
    </select>
    <button @click="player.assign(itemAssign, itemAssignSlot)">Assigner</button>

    <select v-model="itemSell">
      <option v-for="([slot, item, i], index) in equipped" :key="index" :value="[slot, item, i]">{{ item.name }} ({{ slot.name }})</option>
    </select>

    <button @click="player.sell(itemSell[0].id, itemSell[2], shop.estimate(itemSell[1]));shop.buy(itemSell[1])">Vendre</button>
    <button @click="player.remove(itemSell[0].id, itemSell[2])">Retirer du slot</button>
  </div>
</template>

<script>
export default {
  name: "PersoSlots",
  props: {
    player: Object,
    shop: Object
  },
  computed: {
    equipped() {
      return this.player.slots.map((s) => s.items.map((i, index) => [s, i, index])).flat().filter((a) => a.length > 0);
    },
  },
  data() {
    return {
      itemSell: undefined,
      itemAssign: 0,
      itemAssignSlot: 5,
    };
  },
};
</script>

<style scoped>
</style>
