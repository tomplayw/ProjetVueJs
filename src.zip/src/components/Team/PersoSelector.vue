<template>
  <select v-model.number="selected" @change="$emit('change', selected)">
    <option v-for="(player, index) in players" :key="index" :value="index">
      {{ player.name }}
    </option>
  </select>
</template>

<script>
export default {
  name: "PersoSelector",
  props: {
    players: Array
  },
  data() {
    return {
      selected: 0
    };
  },
  emits: ["change"]
};
</script>

<style scoped>

</style>
