<template>
  <h2>{{ player.name }}</h2>
    <slot name="gold" :gold="player.gold">
      <div>Votre bourse contient <b>{{ player.gold }}</b> pièce(s) d'or</div>
    </slot>

    <slot name="level" :level="player.level">
      <div>Votre personnage est au niveau <b>{{ player.level }}</b></div>
    </slot>

  <table>
    <thead>
    <tr>
      <th>Santé</th>
      <th>Force</th>
      <th>Armure</th>
    </tr>
    </thead>
    <tbody>
    <tr>
      <td>{{ player.life + effects(['l']) }}/{{ player.vitality + effects(['L']) }}</td>
      <td>{{ player.strength + effects(["s", "S"]) }}</td>
      <td>{{ player.armor + effects(["a", "A"]) }}</td>
    </tr>
    </tbody>
  </table>
</template>

<script>
export default {
  name: "PersoCaracs",
  props: {
    player: Object
  },
  methods: {
    effects(chars) {
      return this.player.slots.filter((s) => s.id !== 5).reduce((acc1, slot) => {
        return acc1 + slot.items.reduce((acc2, item) => {
          let match = /(.)([+-]\d+)/.exec(item.effect);
          if (!match || !chars.includes(match[1])) return acc2;
          return acc2 + Number(match[2]);
        }, 0);
      }, 0);
    }
  }
};
</script>

<style scoped>

</style>
