<template>
  <div>
    <PersoSelector :players="players" @change="$emit('perso', $event)"/>
    <Perso :currentPlayer="currentPlayer" :currentShop="currentShop" @change="$emit('item', $event)"/>
  </div>
</template>

<script>
import Perso from "./Perso";
import PersoSelector from "./PersoSelector";

export default {
  name: "Team",
  components: {
    Perso,
    PersoSelector
  },
  props: {
    players: Array,
    currentPlayer: Object,
    currentShop: Object
  },
};
</script>

<style scoped>

</style>
