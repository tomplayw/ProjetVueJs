partie obligatoire et optionnelle pour ShopSelector et StreetSelector
